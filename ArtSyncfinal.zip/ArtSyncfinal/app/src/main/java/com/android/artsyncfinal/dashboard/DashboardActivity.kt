package com.android.artsyncfinal.dashboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.android.artsyncfinal.LoginActivity
import com.android.artsyncfinal.ProfileActivity
import com.android.artsyncfinal.R
import com.android.artsyncfinal.app.ArtSyncfinal

class DashboardActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
        val buttonLogout = findViewById<Button>(R.id.buttonLogout)
        val buttonProfile = findViewById<Button>(R.id.buttonProfile)

        buttonLogout.setOnClickListener(){
            Toast.makeText(this, "Logging out!", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        buttonProfile.setOnClickListener(){
            Toast.makeText(this, "Redirecting!", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)


        }
        val textViewWelcome = findViewById<TextView>(R.id.textviewWelcomeMsg)

        val app:ArtSyncfinal = (application as ArtSyncfinal)
        textViewWelcome.setText("Welcome Back ${app.getLoginUser().username}!")
    }
}