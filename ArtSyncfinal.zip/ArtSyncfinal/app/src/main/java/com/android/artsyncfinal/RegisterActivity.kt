package com.android.artsyncfinal

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.android.artsyncfinal.dashboard.DashboardActivity

class RegisterActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.acitivity_register)
        val buttonRegister = findViewById<Button>(R.id.btnSubmit)

        buttonRegister.setOnClickListener() {
            Toast.makeText(this, " ", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
        }

    }
}