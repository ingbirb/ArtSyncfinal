package com.android.artsyncfinal.data

data class User (var username: String="", var password: String="")