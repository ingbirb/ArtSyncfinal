package com.android.artsyncfinal

import android.app.Activity

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.android.artsyncfinal.app.ArtSyncfinal
import com.android.artsyncfinal.dashboard.DashboardActivity
import com.android.artsyncfinal.data.User
import com.android.artsyncfinal.utils.getEdittextValue
import com.android.artsyncfinal.utils.toast

class LoginActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val buttonLogin = findViewById<Button>(R.id.buttonLogin)
        val textviewRegister = findViewById<TextView>(R.id.textviewRegister)

        buttonLogin.setOnClickListener() {
            val username = getEdittextValue(R.id.edittextUsername)
            val password = getEdittextValue(R.id.edittextPassword)
            if (!username.isNullOrEmpty() && !password.isNullOrEmpty()) {
                val app: ArtSyncfinal = (application as ArtSyncfinal)
                val user: User = app.getUser()
                app.setLoginUser(user)
                if (username.equals(user.username, false) && password.equals(
                        user.password,
                        false
                    )
                ) {
                    toast("Login successful.")
                    startActivity(Intent(this, DashboardActivity::class.java))
                } else {
                    toast("Invalid credentials")
                }
            } else {
                toast("Fields cannot be empty")
            }

        }

        textviewRegister.setOnClickListener() {
            Toast.makeText(this, "Redirecting!", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)

        }
    }
    }

