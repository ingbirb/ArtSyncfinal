package com.android.artsyncfinal.utils

import android.app.Activity
import android.widget.EditText
import android.widget.Toast

fun Activity.getEdittextValue(id: Int): String {
    return (findViewById<EditText>(id).text.toString())
}

fun Activity.toast(msg: String) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}