package com.android.artsyncfinal.app

import android.app.Application
import android.util.Log
import com.android.artsyncfinal.data.User

class ArtSyncfinal: Application() {

    private val user = User( "test", "1234")
    private var loginUser = User()

    override fun onCreate() {
        super.onCreate()


        //Setup database
        //Fetch data API
        //Fetch data from local database
        Log.e("ArtSync", "onCreate is called")
    }

    fun getUser() = this.user

    fun setLoginUser(user: User) {
        this.loginUser = user
    }

    fun getLoginUser() = this.loginUser
}